//
//  ContentView.swift
//  homepagepro
//
//  Created by nouf on 03/04/1444 AH.
//   .imageScale(.small)
// Image(systemName: "globe")
import SwiftUI

struct ContentView: View {
    
    var body: some View {
        NavigationView{
            ZStack{
                
                ZStack{
                    Color("Color")
                        .ignoresSafeArea()
                    
                    HStack{
                        NavigationLink(destination: login(), label:{
                            Image(systemName: "person.fill")
                                .padding(.trailing, 200.0)
                                .imageScale(.large)
                                .foregroundColor(Color("Color 1"))
                            
                        })
                        Image(systemName:
                                "magnifyingglass")
                        .foregroundColor(Color("Color 1"))
                        .padding(.trailing, 15.0)
                        NavigationLink(destination: Settings(), label:{
                        Image(systemName: "gearshape.fill")
                            .imageScale(.medium)
                            .foregroundColor(Color("Color 1"))
                        })
                    }
                    .padding(.bottom, 700.0)
                    
                    VStack{
                        Text("Welcome")
                            .font(/*@START_MENU_TOKEN@*/.largeTitle/*@END_MENU_TOKEN@*/)
                            .fontWeight(.bold)
                            .foregroundColor(Color.black)
                            .multilineTextAlignment(.center)
                            .padding(.top, 60.0)
                        
                        
                        
                        
                        ZStack{
                            
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack{
                                    ForEach(AppConfig.bestImages, id: \.self){  inde in
                                        
                                        
                                        VStack{
                                            Image(inde)
                                            
                                                .resizable()
                                                .scaledToFill()
                                                .clipped()
                                                .frame(width:350.0, height: 250)
                                                .cornerRadius(20)
                                                .padding(.leading, 5.0)
                                            
                                        }}}
                                
                            }
                            
                            
                            Text("best Joy you may have✨")
                            
                                .font(.title2)
                                .fontWeight(.bold)
                                .foregroundColor(Color.white)
                                .multilineTextAlignment(.leading)
                                .padding(.trailing, 100.0)
                                .padding(.vertical, 3.0)
                                .padding(.top,220.0)
                            
                        }
                        
                        
                        
                        Text("Activites 🎯")
                            .font(.title2)
                            .fontWeight(.bold)
                            .foregroundColor(Color("Color 1"))
                            .multilineTextAlignment(.leading)
                            .padding(.trailing, 225.0)
                        
                            .padding(.top, 65.0)
                            .padding(.bottom, 20.0)
                        
                        
                        
                        
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack{
                                ForEach(AppConfig.allImages1, id: \.self){ ind in
                                    NavigationLink(destination: act1(), label: {
                                        VStack{
                                            Image(ind)
                                                .resizable()
                                                .scaledToFill()
                                                .clipped()
                                                .frame(width: 220.0, height: 150.0)
                                                .cornerRadius(7)
                                                .padding(.leading, 0.5)
                                            
                                            Text(ind)
                                                .fontWeight(.bold)
                                                .foregroundColor(.brown)
                                            
                                            
                                            
                                        }
                                            
                                        }
                                    )
                                                   }
                                                   }
                                                   }
                                .padding(.leading, 6.0)
                                
                            }
                        }
                    }
                    
                }.navigationBarBackButtonHidden(true)
            }
        
        }

    

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
