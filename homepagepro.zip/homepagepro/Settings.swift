//
//  Settings.swift
//  homepagepro
//
//  Created by Maryam on 11/04/1444 AH.
//

import SwiftUI

struct Settings: View {
    @State private var arENInex = 0
    var arEN = ["Arabic", "English"]
    var body: some View {
        NavigationView{
            ZStack{
                
                
                ZStack{
                    Color("Color")
                        .ignoresSafeArea()
                    VStack{
                        
                        Form {
                            Section() {
                                List(settingList) {settinItem in
                                    NavigationLink(destination:  myaccount()){
                                        HStack{
                                            Image(systemName: "lock.fill")
                                                .resizable()
                                                .frame(width : 20,height: 20 )
                                                .foregroundColor(Color("Color 1"))
                                                .padding(9)
                                            Text(settinItem.name)
                                                .font(.title2)
                                                .foregroundColor(Color("Color 1"))
                                        }
                                    }
                                    HStack{
                                        Image(systemName: "globe")
                                        
                                            .resizable()
                                            .frame(width : 20,height: 20 )
                                            .foregroundColor(Color("Color 1"))
                                            .padding(9)
                                        Picker(selection:$arENInex, label:
                                                
                                                Text("Langauge").font(.title2) .foregroundColor(Color("Color 1"))) {
                                            ForEach(0..<arEN.count) {
                                                Text(self.arEN[$0])
                                                    .font(.title)
                                                    .foregroundColor(Color("Color 1"))
                                                
                                            }
                                        }
                                        
                                    }
                                    HStack{
                                        Image(systemName: "text.bubble.fill")
                                        
                                            .resizable()
                                            .frame(width : 20,height: 20 )
                                            .foregroundColor(Color("Color 1"))
                                            .padding(9)
                                        Text("Connect us")
                                            .font(.title2)
                                            .foregroundColor(Color("Color 1"))
                                    }
                                    HStack{
                                        Image(systemName: "square.and.arrow.up")
                                        
                                            .resizable()
                                            .frame(width : 20,height: 20 )
                                            .foregroundColor(Color("Color 1"))
                                            .padding(9)
                                        Text("Share App")
                                            .font(.title2)
                                            .foregroundColor(Color("Color 1"))
                                    }
                                }}
                            //
                        }                        
                        
                    }
                }
            }.navigationTitle(Text("Settings").font(.subheadline))
            
             
             
    }
}
}

struct Settings_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
