//
//  Image.swift
//  homepagepro
//
//  Created by nouf on 05/04/1444 AH.
//

import Foundation
class AppConfig {
    
    //   static var pagebackground =
    //  static var firstImage = "9"
    
    //   [String]
    static var bestImages :[String] = ["Madain Salih","Tayeb Ism","Goalf","Horse riding","Haiking"]
    static var allImages1 :[String] = ["Madain Salih","Zipline","Tayeb Ism","Ballet","Skateboard","Balloon","Outdoor Yoga","Horse riding","Boxing"]
}
