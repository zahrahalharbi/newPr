//
//  myaccount.swift
//  homepagepro
//
//  Created by Maryam on 12/04/1444 AH.
//

import SwiftUI

struct myaccount: View {
    var body: some View {
        NavigationView{
            ZStack{
                Color("Color")
                    .ignoresSafeArea()
                VStack{
                    List{
                        HStack{
                            Image(systemName: "envelope.fill")
                            
                                .resizable()
                                .frame(width : 20,height: 20 )
                                .foregroundColor(Color("Color 1"))
                                .padding(9)
                            Text("Change email")
                                .font(.title2)
                                .foregroundColor(Color("Color 1"))
                        }
                        HStack{
                            Image(systemName: "phone.fill")
                            
                                .resizable()
                                .frame(width : 20,height: 20 )
                                .foregroundColor(Color("Color 1"))
                                .padding(9)
                            Text("Change number")
                                .font(.title2)
                                .foregroundColor(Color("Color 1"))
                        }
                        HStack{
                            Image(systemName: "lock.fill")
                            
                                .resizable()
                                .frame(width : 20,height: 20 )
                                .foregroundColor(Color("Color 1"))
                                .padding(9)
                            Text("Change password")
                                .font(.title2)
                                .foregroundColor(Color("Color 1"))
                        }
                    }
                }
            }.navigationTitle(Text("My account").font(.subheadline))
             
        }.navigationBarBackButtonHidden(true)
    }
}

struct myaccount_Previews: PreviewProvider {
    static var previews: some View {
        myaccount()
    }
}
