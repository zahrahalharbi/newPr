//
//  _7_100App.swift
//  17-100
//
//  Created by WadiahAlbuhairi on 07/04/1444 AH.
//

import SwiftUI

@main
struct _7_100App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
