//
//  ContentView.swift
//  17-100
//
//  Created by WadiahAlbuhairi on 07/04/1444 AH.
//

import SwiftUI
import PassKit

struct ContentView: View {
    var paymentHandler = PaymentHandler()
    var body: some View {
        ZStack {
            ZStack{
                Color.black
                    .opacity(0.9)
                Image("img_9")
                    .opacity(0.10)
            }
            PaymentButton()
                .frame(width: 228, height: 40, alignment: .center)
                .onTapGesture {
                    paymentHandler.startPayment(paymentSummaryItems: [PKPaymentSummaryItem(label: "Product", amount: 85)])
                }
        }
        
        
        
    }
    
    
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
}

import PassKit

class PaymentHandler: NSObject, ObservableObject {
    func startPayment(paymentSummaryItems: [PKPaymentSummaryItem]) {
        
        // Create our payment request
        let paymentRequest = PKPaymentRequest()
        paymentRequest.paymentSummaryItems = paymentSummaryItems
        paymentRequest.merchantIdentifier = "merchant.de.xxx"
        paymentRequest.merchantCapabilities = .capability3DS
        paymentRequest.countryCode = "SA"
        paymentRequest.currencyCode = "SAR"
        paymentRequest.requiredShippingContactFields = [.phoneNumber, .emailAddress ]
        paymentRequest.supportedNetworks = [.masterCard, .visa,.mada]
        
        // Display our payment request
        let paymentController = PKPaymentAuthorizationController(paymentRequest: paymentRequest)
        paymentController.delegate = self
        paymentController.present(completion: { (presented: Bool) in })
    }
}


/**
 PKPaymentAuthorizationControllerDelegate conformance.
 */
extension PaymentHandler: PKPaymentAuthorizationControllerDelegate {

    func paymentAuthorizationController(_ controller: PKPaymentAuthorizationController, didAuthorizePayment payment: PKPayment, completion: @escaping (PKPaymentAuthorizationStatus) -> Void) {
        completion(.success)
        print("paymentAuthorizationController completion(.success)")
    }

    func paymentAuthorizationControllerDidFinish(_ controller: PKPaymentAuthorizationController) {
        print("DidFinish")
    }
    
    func paymentAuthorizationControllerWillAuthorizePayment(_ controller: PKPaymentAuthorizationController) {
        print("WillAuthorizePayment")
    }

}

struct PaymentButton: UIViewRepresentable {
    func updateUIView(_ uiView: PKPaymentButton, context: Context) { }
    
    func makeUIView(context: Context) -> PKPaymentButton {
        return PKPaymentButton(paymentButtonType: .plain, paymentButtonStyle: .automatic)
    }
}
