//
//  ActivityScreenApp.swift
//  ActivityScreen
//
//  Created by Zahrah. on 31/10/2022.
//

import SwiftUI

@main
struct ActivityScreenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView1()
        }
    }
}
