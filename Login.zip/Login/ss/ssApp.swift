//
//  ssApp.swift
//  ss
//
//  Created by Maryam on 01/04/1444 AH.
//

import SwiftUI

@main
struct ssApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
