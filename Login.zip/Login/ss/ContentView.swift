
import SwiftUI
import AuthenticationServices

struct ContentView: View {
    @State private var name = ""
    @State private var emailAddress = ""
    @State private var pass = ""
    @State private var passConfirm = ""
    @State private var numberphone = ""
    
    
    //sign in with apple
    @Environment(\.colorScheme) var colorScheme
    @AppStorage("email") var email: String = ""
    @AppStorage("firstName") var firstName: String = ""
    @AppStorage("lastName") var lastName: String = ""
    @AppStorage("userId") var userId: String = ""
    //checked
    @State var isChecked:Bool = false
    func toggle(){isChecked = !isChecked}
    var body: some View {
        NavigationView{
         
                
                ZStack{
                    Color("s1")
                   
                        .ignoresSafeArea()
                       
                    
                    
                    
                    VStack{
                        Text("Already have an account?")
                            .font(.title)
                            .bold()
                            .padding()
                        HStack{
                            Image(systemName: "envelope.fill")
                                .resizable()
                                .frame(width : 25,height: 25 )
                                .foregroundColor(.black)
                               
                            
                            TextField("Enter your email", text: $emailAddress)
                                .padding()
                                .frame(width: 300,height: 40)
                            
                               
                                .overlay(RoundedRectangle(cornerRadius:500)
                                    .stroke(Color.black, lineWidth: 2))
                                .padding()
                        }
                        HStack{
                            Image(systemName: "lock.fill")
                                .resizable()
                                .frame(width : 25,height: 25 )
                                .foregroundColor(.black)
                            SecureField("Enter your password", text: $pass)
                                .padding()
                                .frame(width: 300,height: 40)
                            
                              
                                .overlay(RoundedRectangle(cornerRadius:500)
                                    .stroke(Color.black , lineWidth: 2))
                                .padding()
                            
                        }
                        NavigationLink(destination:
                                        
                            ZStack{
                            Color("s1")
                           
                             
                                .ignoresSafeArea()
                           
                            VStack{
                                Image(systemName: "lock.fill")
                                    .resizable()
                                    .frame(width : 70,height: 80 )
                                    .foregroundColor(Color(hue: 0.029, saturation: 0.291, brightness: 0.864))
                                //sty
                                Text("Forgot password")
                                    .font(.largeTitle)
                               
                                Text("Enter your email to get a verification link to able to change your password")
                                    .font(.title3)
                                    .multilineTextAlignment(.center)
                                    .bold()
                                    .padding()
                                HStack{
                                    Image(systemName: "envelope.fill")
                                        .resizable()
                                        .frame(width : 25,height: 25 )
                                        .foregroundColor(.black)
                                       
                                       
                                    
                                    TextField("Enter your email", text: $emailAddress)
                                        .padding()
                                        .frame(width: 300,height: 40)
                                    
                                        .overlay(RoundedRectangle(cornerRadius:500)
                                            .stroke(Color.black, lineWidth: 2))
                                        .padding()
                                }
                                Button("Submit"){
                                    
                                }
                                .foregroundColor(.white)
                                .frame(width: 300,height: 50)
                                .background(Color(hue: 0.029, saturation: 0.291, brightness: 0.864))
                                .cornerRadius(10)
                                .padding()
                               }
                        }
                        )
                        {
                            //page2
                            //st4
                            Button(action: toggle){
                                HStack{
                                    Image(systemName: isChecked ? "checkmark.square": "square")
                                        .foregroundColor(.black)
                                    Text("Remamber me")
                                        .font(.title3)
                                        .foregroundColor(.black)
                                        
                                        
                                    
                                }.padding(.leading )
                                
                                
                            }
                           Spacer()
                                Text("Forgot password?")
                                    .font(.title3)
                                    .padding(.horizontal )
                                
                            
                          
                           
                            
                        }.padding(.bottom, 50)
                        //end
                        
                        Button("Sign in"){
                            
                        }
                        .foregroundColor(.white)
                        .frame(width: 300,height: 50)
                        .background(Color(hue: 0.029, saturation: 0.291, brightness: 0.864))
                        .cornerRadius(10)
                        .padding()
                        // sign in with apple
                        VStack {
                    SignInWithAppleButton(.continue){ request in request.requestedScopes = [.email, .fullName]
                    } onCompletion: { result in
                        switch result{
                        case .success(let auth):
                            switch auth.credential{
                            case let Credential as
                            ASAuthorizationAppleIDCredential:
                                // User Id
                                let userId = Credential.user
                                // User info
                                let email = Credential.email
                                let firstName = Credential.fullName?.givenName
                                let lastName = Credential.fullName?.familyName
                                
                                self.email = email ?? ""
                                self.userId = userId
                                self.firstName = firstName ?? ""
                                self.lastName = lastName ?? ""
                                
                            default:
                                break
                            }
                            
                           
                        case .failure(let error):
                            print(error)
                        }
                    }
                    .signInWithAppleButtonStyle(colorScheme == .dark ? .white : .black)
                    .frame(width: 300,height: 50)
                    .padding()
                   
                    .cornerRadius(10)
                    
                              
                            }
                        //end
                        
                        HStack{
                            Text("You don't have an account?")
                                .font(.title2)
                            
                            NavigationLink(destination:
                                            
                                            ZStack{
                                Color("s1")
                                    .ignoresSafeArea()
                                   
                                VStack{
                                    Text("Create account")
                                        .font(.largeTitle)
                                        .bold()
                                        .padding()
                                    HStack{
                                        Image(systemName: "person.fill")
                                            .resizable()
                                            .frame(width : 30,height: 30 )
                                            .foregroundColor(.black)
                                        
                                        TextField("Enter your name", text: $name)
                                            .padding()
                                            .frame(width: 300,height: 40)
                                        
                                           
                                            .overlay(RoundedRectangle(cornerRadius:500)
                                                .stroke(Color.secondary, lineWidth: 2))
                                            .padding()
                                        
                                    }
                                    HStack{
                                        Image(systemName: "envelope.fill")
                                            .resizable()
                                            .frame(width : 25,height: 25 )
                                            .foregroundColor(.black)
                                        
                                        TextField("Enter your email", text: $emailAddress)
                                            .padding()
                                            .frame(width: 300,height: 40)
                                        
                                          
                                            .overlay(RoundedRectangle(cornerRadius:500)
                                                .stroke(Color.secondary, lineWidth: 2))
                                            .padding()
                                    }
                                    HStack{
                                        Image(systemName: "phone.fill")
                                            .resizable()
                                            .frame(width : 25,height: 25 )
                                            .foregroundColor(.black)
                                        
                                        TextField("Enter your phone", text: $numberphone)
                                        //phone
                                            .keyboardType(.numberPad)
                                        
                                            .padding()
                                            .frame(width: 300,height: 40)
                                        
                                          
                                            .overlay(RoundedRectangle(cornerRadius:500)
                                                .stroke(Color.black, lineWidth: 2))
                                            .padding()
                                    }
                                    HStack{
                                        Image(systemName: "lock.fill")
                                            .resizable()
                                            .frame(width : 25,height: 25 )
                                            .foregroundColor(.black)
                                        SecureField("Enter your password", text: $pass)
                                            .padding()
                                            .frame(width: 300,height: 40)
                                        
                                           
                                            .overlay(RoundedRectangle(cornerRadius:500)
                                                .stroke(Color.black, lineWidth: 2))
                                            .padding()
                                        
                                    }
                                    HStack{
                                        Image(systemName: "lock.fill")
                                            .resizable()
                                            .frame(width : 25,height: 25 )
                                            .foregroundColor(.black)
                                        SecureField("Confirm paasword", text: $passConfirm)
                                            .padding()
                                            .frame(width: 300,height: 40)
                                        
                                           
                                            .overlay(RoundedRectangle(cornerRadius:500)
                                                .stroke(Color.black, lineWidth: 2))
                                            .padding()
                                        
                                    }
                                    Button("Sign up"){
                                        
                                    }
                                    .foregroundColor(.white)
                                    .frame(width: 300,height: 50)
                                    .background(Color(hue: 0.029, saturation: 0.291, brightness: 0.864))
                                    .cornerRadius(10)
                                    .padding()
                                }
                            }){
                                Text("Sign up")
                                    .font(.title2)
                                
                            }
                            
                        }
                    }
                }
            
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
