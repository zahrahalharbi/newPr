//
//  setting1.swift
//  homepagepro
//
//  Created by Maryam on 12/04/1444 AH.
//

import Foundation
struct setting : Identifiable {
    let id = UUID()
   
    let name : String
   
}
let settingList : [setting] = [
    setting(
    
    name : "My account")

]
