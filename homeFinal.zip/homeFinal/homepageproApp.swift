//
//  homepageproApp.swift
//  homepagepro
//
//  Created by nouf on 03/04/1444 AH.
//

import SwiftUI

@main
struct homepageproApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
         
        }
    }
}
